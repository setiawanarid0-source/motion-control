#!/usr/bin/env python3
"""MotionFly R4 production experiment: conservative background-camera observation and 2D correction."""
import argparse,json,math
from pathlib import Path
import cv2,numpy as np
W,H=360,640

def rigid(dx=0.,dy=0.,deg=0.,scale=1.):
 a=math.radians(deg);return np.array([[scale*math.cos(a),-scale*math.sin(a),dx],[scale*math.sin(a),scale*math.cos(a),dy],[0,0,1]],np.float64)

def fit(a,b):
 h,w=a.shape;region=np.zeros((h,w),np.uint8);region[:int(.2*h)]=255;region[int(.8*h):]=255;region[:,:int(.22*w)]=255;region[:,int(.78*w):]=255
 diff=cv2.GaussianBlur(cv2.absdiff(a,b),(7,7),0);region[diff>55]=0
 pts=cv2.goodFeaturesToTrack(a,maxCorners=500,qualityLevel=.008,minDistance=6,mask=region)
 if pts is None or len(pts)<14:return None,0
 f,ok,_=cv2.calcOpticalFlowPyrLK(a,b,pts,None,winSize=(21,21),maxLevel=3)
 if f is None:return None,0
 back,backok,_=cv2.calcOpticalFlowPyrLK(b,a,f,None,winSize=(21,21),maxLevel=3)
 if back is None:return None,0
 valid=(ok[:,0]>0)&(backok[:,0]>0)&(np.linalg.norm(back[:,0]-pts[:,0],axis=1)<1.8)
 p=pts[valid,0];q=f[valid,0]
 if len(p)<12:return None,0
 quadrants=set(zip((p[:,0]>=w/2).astype(int),(p[:,1]>=h/2).astype(int)))
 if len(quadrants)<3:return None,0
 m,ins=cv2.estimateAffinePartial2D(p,q,method=cv2.RANSAC,ransacReprojThreshold=2.1,maxIters=2000,confidence=.995)
 if m is None or ins is None:return None,0
 ratio=float(ins[:,0].mean())
 if ratio<.48 or ins.sum()<11:return None,ratio
 z=np.eye(3);z[:2]=m;return z,ratio

def measure(video,step=3):
 cap=cv2.VideoCapture(str(video))
 if not cap.isOpened():raise ValueError('VIDEO_DECODE_FAILED')
 fps=cap.get(cv2.CAP_PROP_FPS);width=int(cap.get(3));height=int(cap.get(4))
 if not 1<=fps<=240 or width<16 or height<16:raise ValueError('INVALID_VIDEO_GEOMETRY')
 anchor=last=None;cum=np.eye(3);trajectory=[];quality=[];success=0;attempt=0;anchorok=0;n=0
 while True:
  ok,frame=cap.read()
  if not ok:break
  if n%step:
   n+=1;continue
  gray=cv2.cvtColor(cv2.resize(frame,(W,H),interpolation=cv2.INTER_AREA),cv2.COLOR_BGR2GRAY)
  if anchor is None:anchor=gray;last=gray
  else:
   attempt+=1
   k,q=fit(anchor,gray)
   if k is not None:
    cum=k;quality.append(q);success+=1;anchorok+=1
   else:
    k,q=fit(last,gray)
    if k is not None: cum=k@cum;quality.append(q);success+=1
   last=gray
  dx,dy=float(cum[0,2]),float(cum[1,2]);theta=math.degrees(math.atan2(cum[1,0],cum[0,0]));scale=math.hypot(cum[0,0],cum[1,0])
  trajectory.append({'t':round(n/fps,5),'dx':round(dx,3),'dy':round(dy,3),'degrees':round(theta,4),'scale':round(scale,6)})
  n+=1
 cap.release()
 if len(trajectory)<4:raise ValueError('VIDEO_TOO_SHORT')
 v=np.array([[x[k] for k in ('dx','dy','degrees','scale')] for x in trajectory]);ranges=np.ptp(v,axis=0)
 okratio=success/max(attempt,1);aq=anchorok/max(attempt,1);q=np.median(quality) if quality else 0.
 delta=np.diff(v,axis=0)
 maxstep=max(np.linalg.norm(delta[:,:2],axis=1)) if len(delta) else 0
 if okratio<.75 or q<.65 or (aq<.85 and q<.8) or maxstep>10:kind='UNKNOWN'
 elif ranges[3]>.035:kind='ZOOM'
 elif ranges[2]>2:kind='ROTATION'
 elif max(ranges[:2])>18:kind='MOVING'
 elif max(ranges[:2])<3 and ranges[2]<.45 and ranges[3]<.008:kind='STATIC'
 else:kind='UNKNOWN'
 return {'schema':'r4-camera-v1','classification':kind,'original_resolution':[width,height],'work_resolution':[W,H],
  'median_inlier_ratio':round(float(q),3),'match_success_ratio':round(okratio,3),'anchor_success_ratio':round(aq,3),
  'fps':round(fps,3),'sample_frames':len(trajectory),'trajectory':trajectory}

def coords(report,t):
 traj=report['trajectory'];tt=np.array([z['t'] for z in traj]);return rigid(*[float(np.interp(t,tt,[z[key] for z in traj])) for key in ('dx','dy','degrees','scale')])

def correct(src,out,video,destination,max_px=8.):
 if 'UNKNOWN' in (src['classification'],out['classification']):raise ValueError('CAMERA_UNCERTAIN')
 cap=cv2.VideoCapture(video)
 if not cap.isOpened():raise ValueError('OUTPUT_VIDEO_UNREADABLE')
 fps=cap.get(5);w=int(cap.get(3));h=int(cap.get(4))
 writer=cv2.VideoWriter(destination,cv2.VideoWriter_fourcc(*'mp4v'),fps,(w,h))
 if not writer.isOpened():raise ValueError('CORRECTED_VIDEO_WRITER_FAILED')
 n=0;peak=0.;S=np.diag([w/W,h/H,1.])
 try:
  while True:
   ok,frame=cap.read()
   if not ok:break
   target=np.eye(3) if src['classification']=='STATIC' else coords(src,n/fps)
   measured=coords(out,n/fps)
   mat=S@target@np.linalg.inv(measured)@np.linalg.inv(S);aff=mat[:2]
   corners=np.array([[0,0],[w-1,0],[0,h-1],[w-1,h-1],[w/2,h/2]],np.float64)
   shifts=corners@aff[:,:2].T+aff[:,2]-corners;dist=float(np.linalg.norm(shifts,axis=1).max());peak=max(peak,dist)
   if dist>max_px:raise ValueError('CORRECTION_BORDER_RISK')
   writer.write(cv2.warpAffine(frame,aff,(w,h),borderMode=cv2.BORDER_REFLECT_101));n+=1
 finally:cap.release();writer.release()
 if n==0:raise ValueError('EMPTY_OUTPUT')
 return {'frames':n,'max_correction_px':round(peak,3)}

def main():
 p=argparse.ArgumentParser();sub=p.add_subparsers(dest='operation',required=True)
 a=sub.add_parser('analyze');a.add_argument('--video',required=True);a.add_argument('--out',required=True)
 c=sub.add_parser('correct');c.add_argument('--source-report',required=True);c.add_argument('--output-report',required=True);c.add_argument('--video',required=True);c.add_argument('--out',required=True)
 args=p.parse_args()
 if args.operation=='analyze':
  report=measure(args.video);Path(args.out).write_text(json.dumps(report));print(json.dumps({'classification':report['classification'],'median_inlier_ratio':report['median_inlier_ratio']}))
 else:
  report=correct(json.loads(Path(args.source_report).read_text()),json.loads(Path(args.output_report).read_text()),args.video,args.out);print(json.dumps(report))
if __name__=='__main__':main()
